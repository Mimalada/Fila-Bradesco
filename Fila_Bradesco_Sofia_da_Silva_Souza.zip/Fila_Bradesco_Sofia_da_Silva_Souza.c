#include <stdlib.h>
#include <stdio.h>
#include "lista.h"

FILE *abrir_um_arquivo_para_ler();
void bubbleSort(Lista *lista);

int main(void) {
    
    FILE *arquivo = abrir_um_arquivo_para_ler(); //Função para abrir um arquivo.txt e ler ele

    //Função para criar uma lista
    Lista* lista = criar_lista();
    int idadeDosClientes = 0;
    
    printf("Arquivo das idades esta sendo lido.\n");
    printf("\n");

    while(fscanf(arquivo, "%d", &idadeDosClientes) != EOF){ //Vai percorrer por todo o arquivo até chegar no final dele
        inserir_no_final(lista, idadeDosClientes);
    }

    printf("Atualizando a lista.\n");
    bubbleSort(lista); 

    printf("\n");

    printf("Lista atualizada por idade: \n");
    lst_imprime(lista); //Imprime a lista já ordenada

    printf("\n"); 

    printf("Pacientes mais velhos irao ser atendidos agora. Espere!\n");
    remover_pacientes(lista); //Função para liberar os nós começando do começo da lista

    printf("\n");

    printf("Todos os pacientes foram atendidos.\n");
    fclose(arquivo); //Fecha o arquivo
    
    return 0;
 }

 
FILE *abrir_um_arquivo_para_ler(){

    FILE *arquivo = fopen("clientes.txt", "r");
    fseek(arquivo, 0, SEEK_END); //Move o ponteiro(essa barra |) para o final do arquivo
    int tamanho = ftell(arquivo); //Fução usada para medir o tamanho do arquivo
    rewind(arquivo); //Volta para o começo do arquivo

    if(arquivo == NULL){
        printf("O arquivo nao existe!\n");
        exit(1);
    } 
    else if(tamanho == 0){
        printf("O arquivo esta vazio!\n");
        exit(1);
    }

    return arquivo;
}


 void bubbleSort(Lista *lista){

    //Confere se a lista não está vazia
    if(lista->prim == NULL){
        return;
    }

    int trocado = 1; //Afirma logo de cara que houve uma troca
    ListaNo* atual;
    ListaNo* fim = NULL; 
    
    while (trocado != 0) 
    {   
        printf(". "); //É para servir como um "loading"
        trocado = 0;
        atual = lista->prim;

        while (atual->prox != fim) //Percorre a lista a partir do nó atual 
        {
            if(atual->info < atual->prox->info){  //Confere se a idade do nó atual é menor que a idade do próximo nó
                reordena_nos(lista, atual, atual->prox);//Vai trocar os dois nós de lugar
                trocado = 1;
            }else{ //Caso não seja, passa para o próximo nó 
                atual = atual->prox;
            }
        }
        fim = atual->prox; //Também passa para o próximo nó
    }
    
 }