#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

 Lista *criar_lista(){
    //Vai criar uma lista nova e setar seus ponteiros como NULL
    Lista *lista = malloc(sizeof(Lista));
    lista->prim = NULL;
    lista->ult = NULL;

    return lista;
 }

void inserir_no_final(Lista* l, int v){

  ListaNo* novo = malloc(sizeof(ListaNo)); 
  novo->info = v;
  novo->ant = l->ult;
  novo->prox = NULL;

  if (l->ult != NULL){ //Irá conferir se o último nó é de fato o último nó
      l->ult->prox = novo;
  }
  else {
      l->prim = novo;
  }  
  l->ult = novo;
 }

void reordena_nos(Lista *lista, ListaNo *atual, ListaNo *proximo){

    //Confere se nenhum nó é vazio e se certifica de que os elementos são adjacentes
   if(atual == NULL || proximo == NULL || atual == proximo || atual->prox != proximo){
    return;
   }

    //Confere se o nó que vem antes do nó atual existe ou não. No caso, ele existe
    if(atual->ant != NULL){
        atual->ant->prox = proximo;
    } else{
        lista->prim = proximo;
    }

    //Confere se o nó que vem depois do ListaNo proximo existe ou não
    if(proximo->prox != NULL){
        proximo->prox->ant = atual;
    } else{
        lista->ult = atual; 
    }

    atual->prox = proximo->prox; //O ponteiro prox do atual passa a apontar para o próximo do nó "próximo"
    proximo->ant = atual->ant; //O ponteiro ant do "próximo" passa a apontar para o anterior do nó "atual"(que não é mais atual)
    atual->ant = proximo; //O ponteiro ant do nó "atual" recebe o ListaNo proximo
    proximo->prox = atual; //O ponteiro prox do nó "próximo" recebe o ListaNo atual

}

void lst_imprime(Lista* lista){
    ListaNo* atual = lista->prim;

    while (atual != NULL) { //Percorre a lista toda até o final
        printf("%d ", atual->info);
        atual = atual->prox; //Passa para o próximo nó da lista
    }
    printf("\n");
}

void remover_pacientes(Lista* lista){
    //Essa função apenas remove os pacientes da lista a partir da primeira posição

    if(lista == NULL){ //Verifica se a lista está vazia
        printf("A lista esta vazia!");
        return;
    }

    ListaNo* paciente = lista->prim; //Guarda o nó que será removido(começando pelo começo da lista)

    while(paciente != NULL){
        printf("Paciente que sera atendido: %d\n", paciente->info); //Serve como um loading
        lista->prim = paciente->prox;

        if(lista->prim != NULL){ //Se há algum nó no começo da lista, 
            lista->prim->ant = NULL;
        }

        free(paciente);//Cada paciente, após ser "atendido" irá ser removido da memória
        paciente = lista->prim;
    }

    free(lista);
}