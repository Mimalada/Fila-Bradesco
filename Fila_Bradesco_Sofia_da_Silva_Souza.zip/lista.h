/*
    **TAD de funções para listas duplamente encadeadas
    Por: Sofia da Silva Souza 
    30/11/2024

*/

#include <stdlib.h>
#include <stdio.h>

/*
    **Struct responsável por fazer a criação de uma lista.
*/
 typedef struct lista Lista;

 /*
    **Struct responsável por fazer a criação dos nós de uma lista.
*/
 typedef struct listano ListaNo;

 struct lista { 
    ListaNo* prim; 
    ListaNo* ult;
};
 struct listano {
    int info; 
    ListaNo* prox; 
    ListaNo* ant;
 };


/*
    **Função responsável por criar uma lista. Retorna um ponteiro do tipo Lista.
*/
Lista *criar_lista();

/*
    **Função responsável por inserir nós no final da lista. Retorna void.
*/
void inserir_no_final(Lista* l, int v);

/*
    **Função responsável por reordenar os nós de uma lista. Recebe dois nós e troca os dois de posição, mas sem
    fazer com que o resto da lista seja perdida. Não irá criar uma lista nova do zero, apenas mudar de posição os
    dois nós passados como parâmetro.
    Retorna void.
*/
void reordena_nos(Lista *lista, ListaNo *atual, ListaNo *proximo);

/*
    **Função responsável por imprimir a lista. Pode ser usada antes ou depois da função reordena_nos.
    Retorna void.
*/
void lst_imprime(Lista* lista);

/*
    **Função responsável por remover da memória os ponteiros na primeira posição de uma lista. Ao final da remoção
    de todos os nós, a função irá também remover a lista da memória.
    Retorna void.
*/
void remover_pacientes(Lista* lista);